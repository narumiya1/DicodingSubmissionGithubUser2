package com.example.dicodingsubmission2.models

class Repositories (
    var id: Int = 0,
    var name: String = "",
    var html_url: String = ""
)