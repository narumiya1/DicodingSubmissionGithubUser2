package com.example.dicodingsubmission2.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.dicodingsubmission2.R
import com.example.dicodingsubmission2.activities.UserDetailActivity
import com.example.dicodingsubmission2.databinding.ItemListUserBinding
import com.example.dicodingsubmission2.models.User

class UserAdapter : RecyclerView.Adapter<UserAdapter.ViewHolder>() {

    private val mData = ArrayList<User>()

    fun setData(items: ArrayList<User>) {
        mData.clear()
        mData.addAll(items)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
       val view:View = LayoutInflater.from(parent.context).inflate(R.layout.item_list_user,parent,false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(mData[position])
    }

    override fun getItemCount(): Int {
       return mData.size
    }

    inner class ViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val binding = ItemListUserBinding.bind(itemView)
        fun bind(user: User) {
            binding.tvItemUsername.text = user.login
            binding.tvItemLink.text = user.html_url
            Glide.with(itemView.context)
                .load(user.avatar_url)
                .apply(
                    RequestOptions()
                        .error(R.drawable.ic_baseline_broken_image_24)
                        .placeholder(R.drawable.ic_baseline_person_24)
                        .override(55, 55)
                )
                .into(binding.imgItemFotoUser)


            itemView.setOnClickListener {

                val moveWithObjectIntent  = Intent(it.context, UserDetailActivity::class.java)
                moveWithObjectIntent.putExtra(UserDetailActivity.DETAIL_USER, user)
                it.context.startActivity(moveWithObjectIntent)
            }

        }

    }

}